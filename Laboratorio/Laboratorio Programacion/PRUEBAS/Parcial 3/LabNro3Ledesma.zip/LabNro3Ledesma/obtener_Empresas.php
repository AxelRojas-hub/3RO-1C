<?php
require_once 'Empresa.php';

$con = new mysqli("localhost", "root", "", "raileurope");

if ($con->connect_error) {
    die("Error de conexión: " . $con->connect_error);
}

$origen = isset($_GET['origen']) ? $_GET['origen'] : null;
$destino = isset($_GET['destino']) ? $_GET['destino'] : null;

$consulta = "
    SELECT e.idEmpresa, e.nombreEmpresa, e.paisEmpresa, e.webEmpresa, e.logoEmpresa, COUNT(s.idServicio) as cantidadServicios
    FROM empresas e
    JOIN servicios s ON e.idEmpresa = s.idEmpresa
    WHERE (ISNULL(?) OR s.ciudadOrigenServicio = ?)
      AND (ISNULL(?) OR s.ciudadDestinoServicio = ?)
";

if ($origen && !$destino) {
    $consulta = "
        SELECT e.idEmpresa, e.nombreEmpresa, e.paisEmpresa, e.webEmpresa, e.logoEmpresa, COUNT(s.idServicio) as cantidadServicios
        FROM empresas e
        JOIN servicios s ON e.idEmpresa = s.idEmpresa
        WHERE s.ciudadOrigenServicio = ?
        GROUP BY e.idEmpresa
    ";
    $listado = $con->prepare($consulta);
    $listado->bind_param('s', $origen);
} elseif (!$origen && $destino) {
    $consulta = "
        SELECT e.idEmpresa, e.nombreEmpresa, e.paisEmpresa, e.webEmpresa, e.logoEmpresa, COUNT(s.idServicio) as cantidadServicios
        FROM empresas e
        JOIN servicios s ON e.idEmpresa = s.idEmpresa
        WHERE s.ciudadDestinoServicio = ?
        GROUP BY e.idEmpresa
    ";
    $listado = $con->prepare($consulta);
    $listado->bind_param('s', $destino);
} else {
    $consulta = "
        SELECT e.idEmpresa, e.nombreEmpresa, e.paisEmpresa, e.webEmpresa, e.logoEmpresa, COUNT(s.idServicio) as cantidadServicios
        FROM empresas e
        JOIN servicios s ON e.idEmpresa = s.idEmpresa
        WHERE s.ciudadOrigenServicio = ?
          AND s.ciudadDestinoServicio = ?
        GROUP BY e.idEmpresa
    ";
    $listado = $con->prepare($consulta);
    $listado->bind_param('ss', $origen, $destino);
}

$listado->execute();
$resultado = $listado->get_result();
$empresas = [];

while ($row = $resultado->fetch_assoc()) {
    $empresas[] = new Empresa(
        $row['idEmpresa'],
        $row['nombreEmpresa'],
        $row['paisEmpresa'],
        $row['webEmpresa'],
        $row['logoEmpresa'],
        $row['cantidadServicios']
    );
}

echo json_encode(['empresas' => $empresas]);

$con->close();
?>
