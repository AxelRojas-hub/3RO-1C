<?php
class Servicio {
    public $idServicio;
    public $nroServicio;
    public $ciudadOrigenServicio;
    public $ciudadDestinoServicio;
    public $estacionOrigenServicio;
    public $estacionDestinoServicio;
    public $horaSalidaServicio;
    public $horaLlegadaServicio;
    public $frecuenciaServicio;
    public $precioServicio;
    public $idEmpresa;

    public function __construct($idServicio, $nroServicio, $ciudadOrigenServicio, $ciudadDestinoServicio, $estacionOrigenServicio, $estacionDestinoServicio, $horaSalidaServicio, $horaLlegadaServicio, $frecuenciaServicio, $precioServicio, $idEmpresa) {
        $this->idServicio = $idServicio;
        $this->nroServicio = $nroServicio;
        $this->ciudadOrigenServicio = $ciudadOrigenServicio;
        $this->ciudadDestinoServicio = $ciudadDestinoServicio;
        $this->estacionOrigenServicio = $estacionOrigenServicio;
        $this->estacionDestinoServicio = $estacionDestinoServicio;
        $this->horaSalidaServicio = $horaSalidaServicio;
        $this->horaLlegadaServicio = $horaLlegadaServicio;
        $this->frecuenciaServicio = $frecuenciaServicio;
        $this->precioServicio = $precioServicio;
        $this->idEmpresa = $idEmpresa;
    }

    
}
?>
