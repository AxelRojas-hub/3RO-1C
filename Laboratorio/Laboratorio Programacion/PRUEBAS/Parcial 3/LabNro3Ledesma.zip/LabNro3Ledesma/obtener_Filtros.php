<?php
$con = new mysqli("localhost", "root", "", "raileurope");

if ($con->connect_error) {
    die("Error de conexión: " . $con->connect_error);
}

function obtenerCiudades($column) {
    global $con;
    $ciudades = [];
    $resultado = $con->query("SELECT DISTINCT $column FROM servicios");
    while ($row = $resultado->fetch_assoc()) {
        $ciudades[] = $row[$column];
    }
    return $ciudades;
}

$origenes = obtenerCiudades("ciudadOrigenServicio");
$destinos = obtenerCiudades("ciudadDestinoServicio");

echo json_encode(['origenes' => $origenes, 'destinos' => $destinos]);
?>
