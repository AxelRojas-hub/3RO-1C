<?php
require_once 'Servicio.php';

$con = new mysqli("localhost", "root", "", "raileurope");

if ($con->connect_error) {
    die("Error de conexión: " . $con->connect_error);
}

$idEmpresa = isset($_GET['idEmpresa']) ? $_GET['idEmpresa'] : die();
$origen = isset($_GET['origen']) ? $_GET['origen'] : null;
$destino = isset($_GET['destino']) ? $_GET['destino'] : null;

$consulta = "
    SELECT *
    FROM servicios
    WHERE idEmpresa = ?
      AND (ISNULL(?) OR ciudadOrigenServicio = ?)
      AND (ISNULL(?) OR ciudadDestinoServicio = ?)
";

if ($origen && !$destino) {
    $consulta = "
        SELECT *
        FROM servicios
        WHERE idEmpresa = ?
          AND ciudadOrigenServicio = ?
    ";
    $listado = $con->prepare($consulta);
    $listado->bind_param('is', $idEmpresa, $origen);
} elseif (!$origen && $destino) {
    $consulta = "
        SELECT *
        FROM servicios
        WHERE idEmpresa = ?
          AND ciudadDestinoServicio = ?
    ";
    $listado = $con->prepare($consulta);
    $listado->bind_param('is', $idEmpresa, $destino);
} else {
    $consulta = "
        SELECT *
        FROM servicios
        WHERE idEmpresa = ?
          AND ciudadOrigenServicio = ?
          AND ciudadDestinoServicio = ?
    ";
    $listado = $con->prepare($consulta);
    $listado->bind_param('iss', $idEmpresa, $origen, $destino);
}

$listado->execute();
$resultado = $listado->get_result();
$servicios = [];

while ($row = $resultado->fetch_assoc()) {
    $servicios[] = new Servicio(
        $row['idServicio'],
        $row['nroServicio'],
        $row['ciudadOrigenServicio'],
        $row['ciudadDestinoServicio'],
        $row['estacionOrigenServicio'],
        $row['estacionDestinoServicio'],
        $row['horaSalidaServicio'],
        $row['horaLlegadaServicio'],
        $row['frecuenciaServicio'],
        $row['precioServicio'],
        $row['idEmpresa']
    );
}

echo json_encode(['servicios' => $servicios]);

$con->close();
?>
