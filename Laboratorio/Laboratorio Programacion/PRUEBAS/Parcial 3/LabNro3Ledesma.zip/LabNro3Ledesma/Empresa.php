<?php
class Empresa {
    public $idEmpresa;
    public $nombreEmpresa;
    public $paisEmpresa;
    public $webEmpresa;
    public $logoEmpresa;
    public $cantidadServicios;

    public function __construct($idEmpresa, $nombreEmpresa, $paisEmpresa, $webEmpresa, $logoEmpresa, $cantidadServicios) {
        $this->idEmpresa = $idEmpresa;
        $this->nombreEmpresa = $nombreEmpresa;
        $this->paisEmpresa = $paisEmpresa;
        $this->webEmpresa = $webEmpresa;
        $this->logoEmpresa = $logoEmpresa;
        $this->cantidadServicios = $cantidadServicios;
    }

    
}
?>
